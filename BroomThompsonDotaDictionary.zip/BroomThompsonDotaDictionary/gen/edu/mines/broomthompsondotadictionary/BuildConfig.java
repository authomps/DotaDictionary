/** Automatically generated file. DO NOT MODIFY */
package edu.mines.broomthompsondotadictionary;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}